"""
BiasClear API — Main Application

POST /scan         — Scan text for bias (local, deep, or full)
POST /scan/batch   — Batch scan multiple texts
POST /correct      — Correct detected bias in text
GET  /patterns     — List all detection patterns (by domain)
GET  /audit        — Recent audit chain entries
GET  /audit/verify — Verify chain integrity
GET  /health       — Health check
"""

from __future__ import annotations

import asyncio
import hashlib
import re
import time
import uuid
from contextlib import asynccontextmanager
from typing import Optional

from fastapi import FastAPI, HTTPException, Query, Depends, Header
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse, RedirectResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from starlette.requests import Request
from pathlib import Path

import os

from biasclear.config import settings, APP_VERSION
from biasclear.frozen_core import CORE_VERSION

# Track startup time for uptime reporting
_STARTUP_TIME = time.time()

# Track last successful LLM call for health truthfulness
_llm_last_success: float = 0.0
from biasclear.audit import audit_chain
from biasclear.detector import scan_local, scan_deep, scan_full
from biasclear.corrector import correct_bias
from biasclear.patterns.learned import learning_ring
from biasclear.llm.factory import get_provider_with_fallback
from biasclear.auth import require_api_key, AUTH_ENABLED
from biasclear.rate_limit import check_rate_limit
from biasclear.cache import scan_cache
from biasclear.llm import CircuitOpenError
from biasclear.playground_token import (
    create_playground_token,
    validate_playground_token,
)
from biasclear.logging import setup_logging, get_logger
from biasclear.signups import signup_store
from biasclear.schemas.scan import (
    ScanRequest,
    ScanBatchRequest,
    ScanResponse,
    ScanBatchResponse,
    CorrectRequest,
    CorrectResponse,
    CertificateRequest,
    CertificateResponse,
    CertificateVerifyResponse,
    AuditResponse,
    ChainVerification,
    HealthResponse,
)

logger = get_logger("api")

# Production detection
_ON_RENDER = os.getenv("RENDER", "").lower() == "true"
_DOCS_ENABLED = os.getenv("BIASCLEAR_DOCS_ENABLED", "").lower() == "true"

# Hex hash pattern for audit_hash validation
_HEX64_PATTERN = re.compile(r"^[0-9a-f]{64}$")


def _get_client_ip(request: Request) -> str:
    """Extract client IP, respecting X-Forwarded-For from Render's proxy."""
    forwarded = request.headers.get("x-forwarded-for")
    if forwarded:
        # First IP in the chain is the real client
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "0.0.0.0"


# ============================================================
# STARTUP / SHUTDOWN
# ============================================================

async def _cleanup_loop():
    """Background task: purge expired tokens and stale rate-limit windows every 5 minutes."""
    from biasclear.playground_token import cleanup_expired_tokens
    from biasclear.rate_limit import cleanup_stale_windows

    while True:
        await asyncio.sleep(300)  # 5 minutes
        try:
            tokens_removed = cleanup_expired_tokens()
            cleanup_stale_windows(max_age=7200)
            if tokens_removed:
                logger.debug("Cleanup: removed %d expired tokens", tokens_removed)
        except Exception:
            logger.warning("Background cleanup failed", exc_info=True)


# Track canary state for health reporting
_canary_last_run: float = 0.0
_canary_last_passed: bool = False
_canary_consecutive_failures: int = 0


async def _llm_canary_loop():
    """Background canary: lightweight LLM probe every 4 minutes.

    Keeps _llm_last_success fresh so the health endpoint can distinguish
    an idle-but-healthy service from a broken one. Uses a cheap
    generate() call (not a full scan) to minimize cost.
    """
    global _llm_last_success, _canary_last_run, _canary_last_passed, _canary_consecutive_failures

    while True:
        await asyncio.sleep(240)  # 4 minutes — inside the 5-min staleness window
        _canary_last_run = time.time()
        try:
            provider = _get_llm()
            probe = await provider.generate(
                prompt="Respond with exactly: OK",
                temperature=0.0,
            )
            if probe and "OK" in probe.upper():
                _llm_last_success = time.time()
                _canary_last_passed = True
                _canary_consecutive_failures = 0
                logger.debug("LLM canary OK")
            else:
                _canary_last_passed = False
                _canary_consecutive_failures += 1
                logger.warning("LLM canary unexpected response: %s",
                               probe[:100] if probe else "(empty)")
        except Exception as e:
            _canary_last_passed = False
            _canary_consecutive_failures += 1
            logger.warning("LLM canary FAILED: %s", e)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Wire up dependencies on startup."""
    setup_logging()

    # Production guard — warn loudly if auth is not configured on Render
    if os.getenv("RENDER", "").lower() == "true" and not AUTH_ENABLED:
        logger.warning(
            "⚠️  RUNNING ON RENDER WITHOUT AUTH — all endpoints are public. "
            "Set BIASCLEAR_API_KEYS in Render environment variables to enable auth."
        )

    # Warn if LLM credentials are missing for the configured provider
    if settings.LLM_PROVIDER == "gemini" and not settings.GEMINI_API_KEY:
        logger.warning(
            "GEMINI_API_KEY not set — deep and full scan modes will fall back to "
            "local-only analysis. Set GEMINI_API_KEY for full detection capability."
        )
    elif settings.LLM_PROVIDER == "bedrock":
        logger.info("Bedrock provider configured (region=%s, model=%s)",
                    settings.AWS_REGION, settings.BEDROCK_MODEL_ID)

    learning_ring.set_audit_logger(audit_chain.log)

    # Start background cleanup for expired tokens and stale rate-limit windows
    cleanup_task = asyncio.create_task(_cleanup_loop())

    logger.info("BiasClear API starting",
                extra={"core_version": CORE_VERSION, "auth_enabled": AUTH_ENABLED})

    # ── Startup LLM smoke check ──────────────────────────────────
    # Fire a lightweight probe so we know immediately if credentials are broken.
    # Non-blocking: failures are logged but don't prevent startup.
    global _llm_last_success
    try:
        provider = _get_llm()
        probe_result = await provider.generate(
            prompt="Respond with exactly: OK",
            temperature=0.0,
        )
        if probe_result and "OK" in probe_result.upper():
            _llm_last_success = time.time()
            logger.info("LLM smoke check PASSED (provider=%s)", settings.LLM_PROVIDER)
        else:
            logger.warning("LLM smoke check returned unexpected response: %s", probe_result[:100] if probe_result else "(empty)")
    except Exception as e:
        logger.error(
            "LLM smoke check FAILED on startup — deep/full scans will degrade to local-only. "
            "Error: %s", e,
        )

    # Start LLM canary — keeps health status fresh during idle periods
    canary_task = asyncio.create_task(_llm_canary_loop())

    yield
    cleanup_task.cancel()
    canary_task.cancel()
    logger.info("BiasClear API shutting down")


# OpenAPI docs lockdown — disabled in production unless explicitly enabled
_docs_url = "/docs" if (not _ON_RENDER or _DOCS_ENABLED) else None
_openapi_url = "/openapi.json" if (not _ON_RENDER or _DOCS_ENABLED) else None

app = FastAPI(
    title="BiasClear API",
    description=(
        "Structural bias detection engine built on Persistent Influence Theory (PIT). "
        "Detects rhetorical manipulation patterns in text across legal, media, financial, "
        "and general domains. Features a frozen deterministic core (42 patterns), "
        "LLM-powered deep analysis, bias correction, and SHA-256 hash-chained audit trail.\n\n"
        "**Quick Start:** `POST /scan` with `{\"text\": \"your text\", \"mode\": \"local\"}` "
        "to scan for bias.\n\n"
        "**Published preprint:** DOI 10.5281/zenodo.18676405"
    ),
    version=APP_VERSION,
    lifespan=lifespan,
    docs_url=_docs_url,
    openapi_url=_openapi_url,
    openapi_tags=[
        {"name": "Scan", "description": "Scan text for structural bias and distortion patterns."},
        {"name": "Correct", "description": "Rewrite biased text while preserving factual content."},
        {"name": "Certificate", "description": "Generate and verify bias scan certificates."},
        {"name": "Audit", "description": "Tamper-evident SHA-256 hash-chained audit trail."},
        {"name": "Patterns", "description": "Browse frozen core and learned detection patterns."},
        {"name": "Health", "description": "Service health and version information."},
    ],
)

# CORS — set BIASCLEAR_CORS_ORIGINS in production (e.g. "https://biasclear.com")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in settings.CORS_ORIGINS.split(",")],
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["X-API-Key", "Content-Type", "Authorization"],
    allow_credentials=False,
)

# Static assets
_static_dir = Path(__file__).resolve().parent / "static"
if _static_dir.is_dir():
    app.mount("/static", StaticFiles(directory=str(_static_dir)), name="static")


@app.get("/", include_in_schema=False)
async def root():
    """Serve the landing page."""
    index = _static_dir / "index.html"
    if index.exists():
        return FileResponse(str(index), media_type="text/html")
    return JSONResponse({"message": "BiasClear API", "docs": "/docs"})


@app.api_route("/funding.json", methods=["GET", "HEAD"], include_in_schema=False)
async def funding_json():
    """Serve the FLOSS/fund funding manifest."""
    manifest = Path(__file__).resolve().parent.parent / "funding.json"
    if manifest.exists():
        return FileResponse(str(manifest), media_type="application/json")
    return JSONResponse({"error": "funding.json not found"}, status_code=404)


@app.api_route(
    "/.well-known/funding-manifest-urls",
    methods=["GET", "HEAD"],
    include_in_schema=False,
)
async def well_known_funding():
    """FLOSS/fund well-known verification file."""
    return PlainTextResponse("https://biasclear.com/funding.json\n")


@app.get("/privacy", include_in_schema=False)
async def privacy():
    """Serve the privacy policy page."""
    page = _static_dir / "privacy.html"
    if page.exists():
        return FileResponse(str(page), media_type="text/html")
    return JSONResponse({"message": "Privacy policy unavailable"}, status_code=404)


@app.get("/demo", include_in_schema=False)
async def demo_redirect():
    """Redirect /demo to the playground section of the landing page."""
    return RedirectResponse(url="/#playground")


@app.post("/beta-signup", include_in_schema=False)
async def beta_signup(request: Request):
    """Log beta signup interest with privacy-safer audit metadata."""
    try:
        content_type = (request.headers.get("content-type") or "").lower()
        if "application/json" in content_type:
            body = await request.json()
            email = body.get("email", "").strip().lower()
        else:
            # Parse form-encoded body without requiring python-multipart
            from urllib.parse import parse_qs
            raw = (await request.body()).decode()
            parsed = parse_qs(raw)
            email = parsed.get("email", [""])[0].strip().lower()
        if not email or "@" not in email:
            return JSONResponse({"status": "error", "message": "Invalid email"}, status_code=400)
        signup = signup_store.add(email, source="website")
        audit_chain.log(
            event_type="beta_signup",
            data={
                "email_sha256": signup["email_sha256"],
                "email_masked": signup["email_masked"],
                "source": signup["source"],
            },
            core_version=CORE_VERSION,
        )
        logger.info(
            "Beta signup recorded",
            extra={
                "email_masked": signup["email_masked"],
                "email_sha256": signup["email_sha256"],
            },
        )
        return JSONResponse({"status": "ok", "message": "Signup recorded"})
    except Exception:
        logger.error("Beta signup failed", exc_info=True)
        return JSONResponse(
            {"status": "error", "message": "Signup could not be recorded"},
            status_code=500,
        )


@app.get("/beta-signups", include_in_schema=False)
async def get_beta_signups(
    key_id: Optional[str] = Depends(require_api_key),
):
    """Retrieve all beta signup emails from the dedicated signup store."""
    if key_id is None:
        raise HTTPException(status_code=401, detail="API key required.")
    if not AUTH_ENABLED:
        raise HTTPException(status_code=403, detail="Endpoint requires authentication to be enabled.")
    # Backfill historical signups that were stored in the audit chain before
    # privacy hardening moved raw emails into the dedicated signup store.
    legacy_entries = audit_chain.get_recent(limit=500, event_type="beta_signup")
    for entry in legacy_entries:
        legacy_email = entry["data"].get("email")
        if legacy_email:
            signup_store.add(legacy_email, source=entry["data"].get("source", "website"))

    emails = signup_store.get_recent(limit=500)
    return {"total": len(emails), "signups": emails}


# ============================================================
# GLOBAL ERROR HANDLER
# ============================================================

@app.exception_handler(Exception)
async def global_error_handler(request: Request, exc: Exception):
    """Catch unhandled exceptions — return structured error, don't leak internals."""
    logger.error(
        f"Unhandled exception: {type(exc).__name__}",
        extra={"error": str(exc), "path": request.url.path, "method": request.method},
        exc_info=True,
    )
    return JSONResponse(
        status_code=500,
        content={
            "detail": "Internal server error. The scan could not be completed.",
        },
    )


# Lazy LLM provider
_llm = None


def _get_llm():
    global _llm
    if _llm is None:
        _llm = get_provider_with_fallback()
    return _llm


# ============================================================
# PLAYGROUND TOKEN ENDPOINT
# ============================================================

@app.get("/playground/token", include_in_schema=False)
async def get_playground_token(request: Request):
    """Issue a short-lived playground session token."""
    ip = _get_client_ip(request)
    token = create_playground_token(ip)
    if token is None:
        raise HTTPException(
            status_code=429,
            detail="Token issuance rate limit exceeded. Try again in 60 seconds.",
        )
    return {"token": token, "max_uses": 50, "ttl_seconds": 3600}


# ============================================================
# ROUTES
# ============================================================

@app.post("/scan", response_model=ScanResponse, tags=["Scan"])
async def scan_text(
    request: ScanRequest,
    raw_request: Request,
    key_id: Optional[str] = Depends(require_api_key),
    x_playground_token: Optional[str] = Header(None, alias="X-Playground-Token"),
):
    """Scan text for structural bias and distortion patterns.

    Supports three modes:
    - **local**: Frozen core only (free, instant, deterministic)
    - **deep**: LLM-powered analysis (higher quality, 1 API call)
    - **full**: Both layers combined (recommended, enables learning ring)

    Results are cached for 1 hour — identical scans return instantly.
    If the LLM is unavailable, deep/full modes gracefully degrade to local.
    """
    ip = _get_client_ip(raw_request)

    # Authenticate: API key OR playground token required
    if key_id is None:
        if x_playground_token:
            valid, reason = validate_playground_token(x_playground_token, ip)
            if not valid:
                raise HTTPException(
                    status_code=403,
                    detail=f"Invalid playground token: {reason}. Refresh the page to get a new token.",
                )
        elif AUTH_ENABLED:
            raise HTTPException(
                status_code=401,
                detail="Authentication required. Include X-API-Key header or use the playground.",
            )

    check_rate_limit(key_id, ip=ip)
    start = time.time()

    learned = learning_ring.get_active_patterns()
    # Cache key includes learning ring state — hash pattern IDs so any
    # activation/deactivation invalidates cache (not just count changes)
    _pattern_ids = sorted(p.id for p in learned)
    lr_version = hashlib.md5(",".join(_pattern_ids).encode()).hexdigest()[:8] if _pattern_ids else "none"

    # Check cache first — identical scans return instantly
    cached = await scan_cache.get(request.text, request.domain, request.mode, extra=lr_version)
    if cached is not None:
        duration = int((time.time() - start) * 1000)
        logger.info(
            f"Scan cache hit: score={cached.get('truth_score', '?')} mode={request.mode}",
            extra={
                "truth_score": cached.get("truth_score"),
                "scan_mode": request.mode,
                "domain": request.domain,
                "duration_ms": duration,
                "key_id": key_id,
            },
        )
        return cached

    # Circuit breaker: if LLM is down and mode requires it, fall back to local
    try:
        if request.mode == "local":
            result = await scan_local(
                request.text, domain=request.domain, external_patterns=learned,
            )
        elif request.mode == "deep":
            result = await scan_deep(
                request.text, llm=_get_llm(), domain=request.domain,
                learning_ring=learning_ring, audit_chain=audit_chain,
            )
        elif request.mode == "full":
            result = await scan_full(
                request.text,
                llm=_get_llm(),
                domain=request.domain,
                external_patterns=learned,
                learning_ring=learning_ring,
                audit_chain=audit_chain,
            )
        else:
            raise HTTPException(400, f"Invalid mode: {request.mode}")
    except CircuitOpenError:
        # LLM circuit breaker is open — gracefully degrade to local-only
        logger.warning(
            "Circuit breaker open — falling back to local scan",
            extra={"requested_mode": request.mode, "domain": request.domain},
        )
        result = await scan_local(
            request.text, domain=request.domain, external_patterns=learned,
        )
        result["scan_mode"] = f"local (fallback from {request.mode})"
        result["degraded"] = True
        result["degradation_warning"] = (
            "LLM circuit breaker is open due to repeated failures. Results are from "
            "the local deterministic engine only. Some subtle bias patterns may not "
            "be detected. Truth score has been capped at 85."
        )
        # Cap truth_score — local-only can't detect subtle patterns
        if result["truth_score"] > 85:
            result["truth_score"] = 85

    if "error" in result and not result.get("bias_detected"):
        logger.error(
            "LLM provider error during scan",
            extra={"error": result["error"], "scan_mode": request.mode, "domain": request.domain},
        )
        raise HTTPException(502, "LLM provider temporarily unavailable. Please try again.")

    # Track LLM success for health endpoint truthfulness
    global _llm_last_success
    if not result.get("degraded") and result.get("source") != "local_fallback":
        if request.mode in ("deep", "full"):
            _llm_last_success = time.time()

    # Tag which provider actually handled this scan — provider truth per request
    _scan_provider = settings.LLM_PROVIDER
    try:
        p = _get_llm()
        if hasattr(p, "_primary_failed") and p._primary_failed:
            _scan_provider = f"{p._fallback_name} (fallback)"
    except Exception:
        pass

    audit_hash = audit_chain.log(
        event_type=f"scan_{request.mode}",
        data={
            "truth_score": result["truth_score"],
            "bias_detected": result["bias_detected"],
            "severity": result["severity"],
            "pit_tier": result["pit_tier"],
            "domain": request.domain,
            "scan_mode": result["scan_mode"],
            "source": result["source"],
            "flags_count": len(result["flags"]),
            "flag_ids": [flag["pattern_id"] for flag in result["flags"]],
            "key_id": key_id,
            "provider_used": _scan_provider,
        },
        core_version=CORE_VERSION,
    )
    result["audit_hash"] = audit_hash

    # Store in cache — but NEVER cache degraded results. When the LLM recovers,
    # users should get full-quality results, not stale local-only fallbacks.
    if not result.get("degraded"):
        await scan_cache.put(request.text, request.domain, request.mode, result, extra=lr_version)

    duration = int((time.time() - start) * 1000)
    logger.info(
        f"Scan complete: score={result['truth_score']} mode={request.mode}",
        extra={
            "truth_score": result["truth_score"],
            "scan_mode": request.mode,
            "domain": request.domain,
            "flags_count": len(result["flags"]),
            "duration_ms": duration,
            "key_id": key_id,
        },
    )

    return result


@app.post("/scan/batch", response_model=ScanBatchResponse, tags=["Scan"])
async def scan_batch(
    request: ScanBatchRequest,
    raw_request: Request,
    key_id: Optional[str] = Depends(require_api_key),
):
    """Batch scan up to 50 texts concurrently with concurrency cap.

    Each item is scanned independently. Failed items return a placeholder
    result with `scan_mode: "error"` rather than failing the entire batch.
    Batch scan requires an API key — playground tokens are not accepted.
    """
    if key_id is None and AUTH_ENABLED:
        raise HTTPException(401, "Batch scan requires an API key.")
    if len(request.items) > 50:
        raise HTTPException(400, "Batch scan limited to 50 items per request.")
    ip = _get_client_ip(raw_request)
    check_rate_limit(key_id, ip=ip)

    learned = learning_ring.get_active_patterns()

    async def _scan_one(item: ScanRequest) -> dict:
        try:
            if item.mode == "local":
                return await scan_local(
                    item.text, domain=item.domain, external_patterns=learned,
                )
            elif item.mode == "deep":
                return await scan_deep(
                    item.text, llm=_get_llm(), domain=item.domain,
                    learning_ring=learning_ring, audit_chain=audit_chain,
                )
            else:
                return await scan_full(
                    item.text,
                    llm=_get_llm(),
                    domain=item.domain,
                    external_patterns=learned,
                    learning_ring=learning_ring,
                    audit_chain=audit_chain,
                )
        except CircuitOpenError:
            # Degrade to local-only if LLM is down
            result = await scan_local(
                item.text, domain=item.domain, external_patterns=learned,
            )
            result["scan_mode"] = f"local (fallback from {item.mode})"
            result["degraded"] = True
            result["degradation_warning"] = (
                "LLM circuit breaker is open. Result is from the local "
                "deterministic engine only. Truth score capped at 85."
            )
            if result["truth_score"] > 85:
                result["truth_score"] = 85
            return result

    # Concurrency cap: max 10 concurrent LLM calls to prevent overload
    _batch_semaphore = asyncio.Semaphore(10)

    async def _scan_one_limited(item: ScanRequest) -> dict:
        async with _batch_semaphore:
            return await _scan_one(item)

    results = await asyncio.gather(
        *[_scan_one_limited(item) for item in request.items],
        return_exceptions=True,
    )

    successful = [r for r in results if isinstance(r, dict)]
    audit_chain.log(
        event_type="scan_batch",
        data={
            "total": len(request.items),
            "scanned": len(successful),
            "errors": len(results) - len(successful),
            "key_id": key_id,
        },
        core_version=CORE_VERSION,
    )

    clean_results = []
    for r in results:
        if isinstance(r, dict):
            clean_results.append(r)
        else:
            logger.warning(
                "Batch scan item failed",
                extra={"error": str(r), "error_type": type(r).__name__},
            )
            clean_results.append({
                "text": "",
                "truth_score": 0,
                "knowledge_type": "unknown",
                "bias_detected": False,
                "bias_types": [],
                "pit_tier": "none",
                "pit_detail": "",
                "severity": "none",
                "confidence": 0.0,
                "explanation": "Scan failed for this item.",
                "flags": [],
                "impact_projection": None,
                "scan_mode": "error",
                "source": "error",
                "core_version": CORE_VERSION,
            })

    logger.info(
        f"Batch complete: {len(successful)}/{len(request.items)} scanned",
        extra={"key_id": key_id},
    )

    return {
        "results": clean_results,
        "total": len(request.items),
        "scanned": len(successful),
    }


@app.post("/correct", response_model=CorrectResponse, tags=["Correct"])
async def correct_text(
    request: CorrectRequest,
    raw_request: Request,
    key_id: Optional[str] = Depends(require_api_key),
    x_playground_token: Optional[str] = Header(None, alias="X-Playground-Token"),
):
    """Rewrite biased text to remove structural distortion while preserving facts.

    Requires a previous scan result as input. Uses iterative LLM correction
    with post-correction verification (up to 3 passes). Returns the corrected
    text, a list of changes made, and visual diff spans.
    """
    ip = _get_client_ip(raw_request)

    # Authenticate: API key OR playground token required
    if key_id is None:
        if x_playground_token:
            valid, reason = validate_playground_token(x_playground_token, ip)
            if not valid:
                raise HTTPException(
                    status_code=403,
                    detail=f"Invalid playground token: {reason}.",
                )
        elif AUTH_ENABLED:
            raise HTTPException(
                status_code=401,
                detail="Authentication required. Include X-API-Key header.",
            )

    check_rate_limit(key_id, ip=ip)

    result = await correct_bias(
        text=request.text,
        scan_result=request.scan_result,
        llm=_get_llm(),
        domain=request.domain,
    )

    audit_chain.log(
        event_type="correction",
        data={
            "changes_count": len(result.get("changes_made", [])),
            "bias_removed": result.get("bias_removed", []),
            "confidence": result.get("confidence", 0.0),
            "key_id": key_id,
        },
        core_version=CORE_VERSION,
    )

    return result


@app.post("/certificate", response_model=CertificateResponse, tags=["Certificate"])
async def generate_certificate(
    request: CertificateRequest,
    key_id: Optional[str] = Depends(require_api_key),
):
    """Generate a verifiable HTML certificate for a completed bias scan.

    The certificate is a self-contained HTML document with truth score,
    detected flags, PIT tier analysis, and a verification link tied to
    the audit chain. Suitable for attaching to legal filings, editorial
    reviews, or compliance documentation.
    """
    if key_id is None and AUTH_ENABLED:
        raise HTTPException(401, "Certificate generation requires an API key.")

    from datetime import datetime, timezone
    from biasclear.certificate import generate_certificate_html, compute_certificate_id

    check_rate_limit(key_id)

    issued_at = datetime.now(timezone.utc).isoformat()
    certificate_id = compute_certificate_id(request.text, issued_at)

    # Build verify URL from configuration (not hardcoded)
    verify_url = f"{settings.BASE_URL}/certificate/verify/{request.audit_hash}"

    html = generate_certificate_html(
        text=request.text,
        scan_result=request.scan_result,
        audit_hash=request.audit_hash,
        certificate_id=certificate_id,
        issued_at=issued_at,
        verify_url=verify_url,
    )

    audit_chain.log(
        event_type="certificate_generated",
        data={
            "certificate_id": certificate_id,
            "audit_hash": request.audit_hash,
            "truth_score": request.scan_result.get("truth_score"),
            "key_id": key_id,
        },
        core_version=CORE_VERSION,
    )

    logger.info(
        "Certificate generated",
        extra={"audit_hash": request.audit_hash, "key_id": key_id},
    )

    return {
        "certificate_id": certificate_id,
        "audit_hash": request.audit_hash,
        "html": html,
        "issued_at": issued_at,
        "verify_url": verify_url,
    }


@app.get("/certificate/verify/{audit_hash}", response_model=CertificateVerifyResponse, tags=["Certificate"])
async def verify_certificate(audit_hash: str):
    """Verify a certificate by its audit chain hash. No authentication required.

    Returns whether the hash exists in the audit chain, along with the
    original event type, timestamp, and truth score.
    """
    # Validate audit_hash format — must be a 64-char hex string
    if not _HEX64_PATTERN.match(audit_hash):
        raise HTTPException(400, "Invalid audit hash format. Expected 64-character hex string.")

    entries = audit_chain.get_recent(limit=500)
    for entry in entries:
        if entry["hash"] == audit_hash:
            return {
                "verified": True,
                "audit_hash": audit_hash,
                "event_type": entry["event_type"],
                "timestamp": entry["timestamp"],
                "truth_score": entry["data"].get("truth_score"),
            }

    return {
        "verified": False,
        "audit_hash": audit_hash,
    }


@app.get("/audit", response_model=AuditResponse, tags=["Audit"])
async def get_audit(
    limit: int = Query(10, ge=1, le=100, description="Number of entries to return (1-100)."),
    event_type: Optional[str] = Query(None, description="Filter by event type (e.g. scan_local, correction)."),
    key_id: Optional[str] = Depends(require_api_key),
):
    """Retrieve recent audit chain entries.

    The audit chain is a SHA-256 hash-linked append-only log of all system events.
    Each entry references the previous entry's hash, creating a tamper-evident chain.
    """
    entries = audit_chain.get_recent(limit=limit, event_type=event_type)
    # Strip prev_hash from responses — internal chain detail
    for entry in entries:
        entry.pop("prev_hash", None)
    return {
        "entries": entries,
        "total_count": audit_chain.get_count(),
    }


@app.get("/audit/verify", response_model=ChainVerification, tags=["Audit"])
async def verify_audit(
    limit: int = Query(100, ge=1, le=1000, description="Number of entries to verify (1-1000)."),
    key_id: Optional[str] = Depends(require_api_key),
):
    """Verify integrity of the audit chain by checking hash links.

    Walks the chain and confirms each entry's hash matches its content
    and links correctly to the previous entry. Returns any broken links found.
    """
    result = audit_chain.verify_chain(limit=limit)

    audit_chain.log(
        event_type="chain_verified",
        data=result,
        core_version=CORE_VERSION,
    )

    return result


@app.get("/health", response_model=HealthResponse, tags=["Health"])
async def health():
    """Service health check. No authentication required.

    Returns current version, LLM provider status, learning ring statistics,
    total scans processed, and uptime.
    """
    all_learned = learning_ring.get_all_patterns()
    audit_count = audit_chain.get_count()

    total_scans = audit_chain.get_count(event_prefix="scan_")

    # Check LLM availability via circuit breaker state AND recent success
    llm_available = True
    llm_status = "ready"
    try:
        provider = _get_llm()
        if hasattr(provider, "circuit_breaker"):
            if provider.circuit_breaker.is_open:
                llm_available = False
                llm_status = "circuit_open"
    except Exception:
        logger.warning("LLM availability check failed in health endpoint", exc_info=True)
        llm_available = False
        llm_status = "provider_error"

    # Compute time since last successful LLM scan
    llm_last_success_ago = None
    if _llm_last_success > 0:
        llm_last_success_ago = int(time.time() - _llm_last_success)
        # Truthfulness: if LLM hasn't succeeded in >5 minutes despite being
        # "ready" (circuit breaker resets after 60s), mark as stale/unavailable
        if llm_last_success_ago > 300 and llm_available:
            llm_available = False
            llm_status = "stale"
    elif llm_available:
        # No successful LLM call ever recorded — check uptime to distinguish
        # fresh start from long-running failure
        uptime = int(time.time() - _STARTUP_TIME)
        if uptime > 300:
            # Running >5 min with zero LLM successes — something is wrong
            llm_available = False
            llm_status = "never_succeeded"
        else:
            llm_status = "no_requests_yet"

    # Report the ACTUAL provider in use, not just the configured one.
    # If the FallbackProvider has silently switched, surface that truth.
    actual_provider = settings.LLM_PROVIDER
    provider_fallback_active = False
    try:
        p = _get_llm()
        if hasattr(p, "_primary_failed") and p._primary_failed:
            actual_provider = f"{p._fallback_name} (fallback)"
            provider_fallback_active = True
    except Exception:
        pass

    return {
        "status": "operational",
        "version": APP_VERSION,
        "core_version": CORE_VERSION,
        "llm_provider": settings.LLM_PROVIDER,
        "llm_provider_actual": actual_provider,
        "llm_provider_fallback_active": provider_fallback_active,
        "llm_available": llm_available,
        "llm_status": llm_status,
        "llm_last_success_ago": llm_last_success_ago,
        "llm_canary": {
            "enabled": True,
            "interval_seconds": 240,
            "last_passed": _canary_last_passed,
            "last_run_ago": int(time.time() - _canary_last_run) if _canary_last_run > 0 else None,
            "consecutive_failures": _canary_consecutive_failures,
        },
        "audit_entries": 0 if _ON_RENDER else audit_count,
        "total_scans": total_scans,
        "learned_patterns_active": len([p for p in all_learned if p["status"] == "active"]),
        "learned_patterns_staging": len([p for p in all_learned if p["status"] == "staging"]),
        "learning_enabled": True,
        "uptime_seconds": int(time.time() - _STARTUP_TIME),
    }


@app.get("/stats", tags=["Health"])
async def stats():
    """Public usage statistics. No authentication required.

    Returns scan counts by mode, score distribution, top patterns fired,
    and activity over the last 24 hours. Useful for dashboards and
    investor/grant due diligence.
    """
    recent = audit_chain.get_recent(limit=500)

    # Count scans by mode
    scans = [e for e in recent if e["event_type"].startswith("scan_")]
    mode_counts = {}
    score_buckets = {"0-20": 0, "21-40": 0, "41-60": 0, "61-80": 0, "81-100": 0}
    pattern_fires = {}

    for scan in scans:
        data = scan.get("data", {})
        mode = data.get("scan_mode", data.get("mode", "unknown"))
        mode_counts[mode] = mode_counts.get(mode, 0) + 1

        # Score distribution
        score = data.get("truth_score")
        if score is not None:
            if score <= 20:
                score_buckets["0-20"] += 1
            elif score <= 40:
                score_buckets["21-40"] += 1
            elif score <= 60:
                score_buckets["41-60"] += 1
            elif score <= 80:
                score_buckets["61-80"] += 1
            else:
                score_buckets["81-100"] += 1

        # Pattern fire frequency
        flag_ids = data.get("flag_ids")
        if isinstance(flag_ids, list):
            for pid in flag_ids:
                pattern_fires[pid] = pattern_fires.get(pid, 0) + 1
            continue

        for flag in data.get("flags", []):
            pid = flag.get("pattern_id", "unknown")
            pattern_fires[pid] = pattern_fires.get(pid, 0) + 1

    # Sort patterns by frequency
    top_patterns = sorted(
        pattern_fires.items(), key=lambda x: x[1], reverse=True
    )[:10]

    # 24-hour activity
    from datetime import datetime, timezone, timedelta
    cutoff_24h = (datetime.now(timezone.utc) - timedelta(hours=24)).isoformat()
    scans_24h = sum(1 for s in scans if s.get("timestamp", "") > cutoff_24h)
    corrections_24h = sum(
        1 for e in recent
        if e["event_type"] == "correction" and e.get("timestamp", "") > cutoff_24h
    )

    total_audit = audit_chain.get_count()
    total_scans_exact = audit_chain.get_count(event_prefix="scan_")
    all_learned = learning_ring.get_all_patterns()

    return {
        "total_scans": total_scans_exact,
        "total_audit_entries": total_audit,
        "scans_by_mode": mode_counts,
        "score_distribution": score_buckets,
        "top_patterns_fired": [{"pattern_id": p, "count": c} for p, c in top_patterns],
        "last_24h": {
            "scans": scans_24h,
            "corrections": corrections_24h,
        },
        "learning_ring": {
            "active": len([p for p in all_learned if p["status"] == "active"]),
            "staging": len([p for p in all_learned if p["status"] == "staging"]),
            "total": len(all_learned),
        },
        "uptime_seconds": int(time.time() - _STARTUP_TIME),
    }


@app.get("/patterns", tags=["Patterns"])
async def get_patterns(
    domain: str = Query("general", pattern="^(general|legal|media|financial|auto)$",
                        description="Domain filter: general, legal, media, financial, or auto (all)."),
    key_id: Optional[str] = Depends(require_api_key),
):
    """List all active detection patterns for a domain.

    Returns both frozen core patterns (immutable, deterministic) and
    learned patterns (governance-approved expansions). Use `domain=auto`
    to see all patterns across all domains.
    """
    from biasclear.frozen_core import frozen_core
    check_rate_limit(key_id)

    patterns = frozen_core.get_patterns(domain=domain)
    learned = learning_ring.get_active_patterns()

    # Add learned patterns
    learned_dicts = [
        {
            "id": p.id,
            "name": p.name,
            "description": p.description,
            "pit_tier": p.pit_tier,
            "severity": p.severity,
            "principle": p.principle,
            "domain": "learned",
        }
        for p in learned
    ]

    return {
        "domain": domain,
        "core_version": CORE_VERSION,
        "frozen_patterns": len(patterns),
        "learned_patterns": len(learned_dicts),
        "total_patterns": len(patterns) + len(learned_dicts),
        "patterns": patterns + learned_dicts,
    }


@app.get("/patterns/learned", tags=["Patterns"])
async def get_learned_patterns(
    key_id: Optional[str] = Depends(require_api_key),
):
    """List all learned patterns with full governance metadata.

    Includes staging, active, and deactivated patterns with their
    confirmation counts, false positive rates, and activation thresholds.
    """
    all_patterns = learning_ring.get_all_patterns()
    active = [p for p in all_patterns if p["status"] == "active"]
    staging = [p for p in all_patterns if p["status"] == "staging"]
    deactivated = [p for p in all_patterns if p["status"] == "deactivated"]

    return {
        "core_version": CORE_VERSION,
        "total": len(all_patterns),
        "active": len(active),
        "staging": len(staging),
        "deactivated": len(deactivated),
        "activation_threshold": learning_ring.activation_threshold,
        "fp_limit": learning_ring.fp_limit,
        "patterns": all_patterns,
    }


# --- Request ID Middleware ---
@app.middleware("http")
async def add_request_id(request: Request, call_next):
    """Generate a unique request ID for forensic tracing."""
    request_id = str(uuid.uuid4())
    request.state.request_id = request_id
    response = await call_next(request)
    response.headers["X-Request-ID"] = request_id
    return response


# --- Security + Version Headers Middleware ---
@app.middleware("http")
async def add_security_headers(request: Request, call_next):
    """Add security and version headers to all responses."""
    response = await call_next(request)
    # Version headers
    response.headers["X-BiasClear-Version"] = APP_VERSION
    response.headers["X-Core-Version"] = CORE_VERSION
    # Security headers
    response.headers["Strict-Transport-Security"] = "max-age=63072000; includeSubDomains; preload"
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    response.headers["X-Permitted-Cross-Domain-Policies"] = "none"
    response.headers["Cross-Origin-Opener-Policy"] = "same-origin"
    response.headers["Cross-Origin-Resource-Policy"] = "same-origin"
    # CSP — allows inline scripts/styles for the landing page
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; "
        "script-src 'self' 'unsafe-inline'; "
        "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
        "font-src 'self' https://fonts.gstatic.com; "
        "img-src 'self' data: https://img.shields.io; "
        "connect-src 'self'; "
        "frame-ancestors 'none'"
    )
    return response


# --- Body Size Limit Middleware ---
_MAX_BODY_BYTES = 1_048_576  # 1 MB


@app.middleware("http")
async def enforce_body_size_limit(request: Request, call_next):
    """Reject requests exceeding 1MB — guards both Content-Length and chunked bodies."""
    content_length = request.headers.get("content-length")
    if content_length:
        try:
            if int(content_length) > _MAX_BODY_BYTES:
                return JSONResponse(
                    status_code=413,
                    content={"detail": "Request body too large."},
                )
        except ValueError:
            pass  # Malformed content-length; let the framework handle it

    # For methods that carry a body, also check actual size
    # (catches chunked transfer encoding with no Content-Length header)
    if request.method in ("POST", "PUT", "PATCH"):
        body = await request.body()
        if len(body) > _MAX_BODY_BYTES:
            return JSONResponse(
                status_code=413,
                content={"detail": "Request body too large."},
            )

    return await call_next(request)


# --- Request Logging Middleware ---
@app.middleware("http")
async def log_requests(request: Request, call_next):
    """Log every API request with method, path, status, duration."""
    path = request.url.path
    # Skip noise: static assets and health checks
    if path.startswith("/static") or path == "/health":
        return await call_next(request)

    start = time.time()
    response = await call_next(request)
    duration_ms = round((time.time() - start) * 1000, 1)

    logger.info(
        f"{request.method} {path} → {response.status_code} ({duration_ms}ms)",
        extra={
            "method": request.method,
            "path": path,
            "status_code": response.status_code,
            "duration_ms": duration_ms,
        },
    )
    return response
