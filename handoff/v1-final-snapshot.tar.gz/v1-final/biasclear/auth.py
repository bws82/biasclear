"""
Auth Middleware — API Key Validation

Simple API key authentication. Keys are stored as environment
variables for now. Phase 4 (enterprise) replaces this with
multi-tenant key management backed by a database.

Keys are checked via a FastAPI dependency that can be injected
into any route.
"""

from __future__ import annotations

import logging
import os
import hashlib
import secrets
from typing import Optional

from fastapi import HTTPException, Security, Depends
from fastapi.security import APIKeyHeader

logger = logging.getLogger("biasclear.auth")

# Header name for API key
API_KEY_HEADER = APIKeyHeader(name="X-API-Key", auto_error=False)

# Load valid keys from environment
# Format: comma-separated list of keys
# Example: BIASCLEAR_API_KEYS=key1,key2,key3
_RAW_KEYS = os.getenv("BIASCLEAR_API_KEYS", "")
_VALID_KEY_HASHES: set[str] = set()

# Store hashes, not plaintext — keys should never sit in memory as strings
for key in _RAW_KEYS.split(","):
    key = key.strip()
    if key:
        _VALID_KEY_HASHES.add(hashlib.sha256(key.encode()).hexdigest())

# Dev mode: if no keys configured, auth is disabled
AUTH_ENABLED = len(_VALID_KEY_HASHES) > 0

# Startup validation — warn or fail-closed
if not AUTH_ENABLED:
    _require_auth = os.getenv("BIASCLEAR_REQUIRE_AUTH", "").lower() == "true"
    if _require_auth:
        raise RuntimeError(
            "BIASCLEAR_REQUIRE_AUTH=true but no BIASCLEAR_API_KEYS configured. "
            "Refusing to start with authentication disabled in production."
        )
    logger.warning(
        "BIASCLEAR_API_KEYS not set — authentication DISABLED. "
        "Set BIASCLEAR_REQUIRE_AUTH=true in production to fail-closed."
    )


def _verify_key(api_key: str) -> bool:
    """Verify an API key against stored hashes."""
    if not api_key:
        return False
    key_hash = hashlib.sha256(api_key.encode()).hexdigest()
    return key_hash in _VALID_KEY_HASHES


async def require_api_key(
    api_key: Optional[str] = Security(API_KEY_HEADER),
) -> Optional[str]:
    """
    FastAPI dependency — validates the API key if provided.

    Returns the key hash (for audit logging), or None if no key was
    provided.  Routes that accept playground tokens need key_id=None
    to fall through to their own token validation; routes that
    strictly require an API key check ``key_id is None`` themselves.

    Raises 403 only for *invalid* keys (present but wrong).
    """
    if not AUTH_ENABLED:
        return None  # Dev mode — no auth required

    if not api_key:
        return None  # Let route decide (playground token, etc.)

    if not _verify_key(api_key):
        raise HTTPException(
            status_code=403,
            detail="Invalid API key.",
        )

    # Return hash for audit logging (never log the actual key)
    return hashlib.sha256(api_key.encode()).hexdigest()[:12]


def generate_api_key() -> str:
    """Generate a new API key. Utility for key provisioning."""
    return f"bc_{secrets.token_urlsafe(32)}"
