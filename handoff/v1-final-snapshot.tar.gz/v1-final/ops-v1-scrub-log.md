# v1-final scrub log

This tree is the retired v1 code, kept so the PIT preprint stays reproducible. It is a scrubbed, history-free snapshot.

- **Source:** `git archive` of `origin/main` at commit `7e15c6c19a4dd75ddac8a69f73c8d493283f3f82` (v2 kickoff, #17). It was not copied from a working folder.
- **Scope:** Remove private files and personal details, generalize dated litigation specifics in test inputs, and withdraw regulatory-alignment badges and pricing from public pages. No other code was refactored.
- **Check:** `python -m pytest tests/ -q` passes on this tree (327 passed). `python run_calibration.py --json` gives the same metrics and per-sample truth scores as before the scrub, for every domain, and v1's `evaluate()` returns the same flags for every corpus sample in all five domain settings.
- **Build artifacts:** the snapshot holds no `__pycache__`, `.pyc` or `*.db` files. Delete any that a local test run creates before tagging.

## Files removed

| File | Why |
|---|---|
| `funding.json` | Funding manifest. It held a personal name, a personal email address and a personal sponsor account. `api/main.py` already returns 404 when the file is missing, so no code change was needed. |
| `.github/FUNDING.yml` | Sponsor button config that pointed at a personal account. |
| `api/static/logo.jpeg` | Raster logo image, removed by policy. The page now uses a text wordmark (see below). |
| `ops/BOARD.md`, `ops/OWNER_STEPS.md` (the whole `ops/` folder) | v1-era planning notes and the owner's click-list. They hold no code and aren't needed to reproduce the preprint. Their account, cleanup and security notes are out of date and are not for publication; the current plan lives in the main branch's `ops/`. `AGENTS.md`, `CLAUDE.md` and `.github/CODEOWNERS` still mention `ops/` and were left as-is. |

## Files edited

| File | Change | Why |
|---|---|---|
| `README.md` | Added a boxed notice at the top: retired v1, kept for preprint reproducibility, claims withdrawn. | Marks the archive clearly. The BibTeX citation of the preprint is unchanged. |
| `README.md` | Added one line to the notice: links to the original repository path refer to the old repository, and the project now lives at `github.com/biasclear/biasclear`. | The old links will become a pointer stub. |
| `pyproject.toml` | `authors` changed to `BiasClear contributors`. | Removes a personal name from package metadata. |
| `api/static/index.html` | Removed the favicon link to the deleted raster logo. | The file no longer exists. |
| `api/static/index.html` | Replaced the nav logo image with the text wordmark `Bias<span>Clear</span>`, using the page's existing `.logo span` style. | The raster logo was removed. |
| `api/static/index.html` | Removed the two "Designed for SB 205 / EU AI Act Alignment" badges from the compliance bar. | Compliance claims are withdrawn. |
| `api/static/index.html` | Removed the Pricing section, including its "Alignment reports (SB 205, EU AI Act)" line. The unused `.pricing-*` CSS was left in place. | Pricing is withdrawn. Leaving the CSS avoids refactoring. |
| `api/static/index.html` | Removed the personal bio paragraph from About. | It held a personal name, location, employer and work history. |
| `api/static/index.html` | Removed the About sentence claiming alignment with SB 205 and the EU AI Act. The rest of that paragraph (preprint, license) is kept. | Compliance claims are withdrawn. |
| `api/static/index.html` | Removed the professional-networking profile link from About. | Personal profile. |
| `api/static/index.html` | Changed the footer copyright from a personal name to `BiasClear contributors`. | Personal name. |
| `api/static/index.html` | Replaced the personal email address with `hello@biasclear.com` (3 places: About link, its label, the rate-limit message). | Uses the public contact. |
| `api/static/privacy.html` | Replaced the personal email address with `hello@biasclear.com` (2 links). | Uses the public contact. The test for `/privacy` still passes. |
| `docs/FUNDER_ONE_PAGER.md` | Removed the personal name from the "Solo developer" line. | Personal name. |
| `docs/FUNDER_ONE_PAGER.md` | Changed the Contact line to `hello@biasclear.com` only. | Removes a personal name, personal email address and profile link. |
| `docs/REVIEWER_PACKET.md` | Changed the Contact line to `hello@biasclear.com` only. | Removes a personal name, personal email address and profile link. |
| `calibration/corpus_parser.py` | In the module docstring's format example, replaced the `source:` line with `source: synthetic example`. | The example named a real law firm and a docket reference. Docstring only; no behavior change. |
| `tests/test_calibration.py` | In the input of `test_clean_text_scores_100`, replaced the date and docket number with generic values. | Dated litigation specifics could echo a real legal matter. The test still passes; the sentence still gets no flags. |
| `calibration/corpus/legal_corpus.txt` | In clean samples #0 and #6 (0-based), replaced the dates with generic ones. In #6, also replaced the state statute citation at the end with "the applicable statute". Other wording, the federal statute citation in #0, and all tags are unchanged. | Same reason: a dated fact pattern tied to one jurisdiction could echo a real legal matter. Calibration output is unchanged (see Check above). |
| `ops-v1-scrub-log.md` | New file (this log). | Records what was scrubbed. |

## Checked and left unchanged

- `scripts/smoke_check.sh`: kept. It reads the API key only from its first argument or `BIASCLEAR_API_KEY` and has an empty default. It contains no key and no default key value.
- `*.db`: none were present in the archive.
- `docs/OPERATIONS_CHECKLIST.md`, `docs/PRODUCTION_DEPLOYMENT_SOURCE_OF_TRUTH.md`: no personal details, alignment badges or pricing.
- `README.md` BibTeX block: kept as an academic citation of the preprint.
- Well-known public figures named in test inputs, examples and quoted news text (`tests/test_frozen_core.py`, `scripts/smoke_check.sh`, `docs/FUNDER_ONE_PAGER.md`, `docs/REVIEWER_PACKET.md`, `api/static/index.html`, two samples in `calibration/corpus/media_corpus.txt`): kept on purpose. They are public officials in symmetric test pairs and news quotations, not private data, and changing them would change what v1's tests and calibration check.
- Two links in `api/static/index.html` to a public forum post that introduced v1: kept on purpose. The post is already public and isn't a personal profile.
- `api/main.py`: not edited, because this scrub changes no code. Its OpenAPI description still contains a line about SB 205 / EU AI Act alignment; the README notice withdraws that claim. It also still defines two funding routes: `/funding.json`, which now returns 404, and `/.well-known/funding-manifest-urls`, which still returns the URL of that removed manifest.
- GitHub URLs in docs, pages, `pyproject.toml` and `.github/CODEOWNERS` still point to the original owner account's repository path. They were left as-is; the README notice says where the project lives now.

## Grep gate

The gate ran a case-insensitive search over this whole tree, text and binary files alike. It used these patterns:

- a consumer webmail domain
- the former location
- the former employer
- a professional-networking site
- the former personal mailbox prefix
- BiasClear API keys (`bc_` plus 20 or more key characters)
- AWS access-key prefixes
- Google API-key prefixes
- the law firm and docket reference removed from the corpus parser docstring
- US phone numbers
- any mailbox token (a word followed by the at sign), whether a full address or a bare mailbox prefix. Each hit was reviewed. What remains is the public contact, reserved example-domain test addresses, a form placeholder, and font-axis syntax in font URLs, none of which is a personal mailbox.

The patterns are described here instead of quoted, so this log cannot match itself. The hard patterns found no matches.

## Secret scan

gitleaks, using the main branch's `.gitleaks.toml`, reports one finding in this tree: the fake key literal in `tests/test_infra.py` that `test_verify_key_valid` hashes. It is not a real key. The main branch's `.gitleaks.toml` allowlists exactly that literal in exactly that file, so the `secret-scan` check stays green once the `v1-final` tag is pushed.

## PM follow-up edits (2026-09-27)
- api/main.py: removed the "SB 205 / EU AI Act alignment" line from the API description (withdrawn compliance claim).
- api/static/index.html: removed both links to a forum post (personal byline) and the "Development supported by AWS Activate" sentence (unverified sponsorship claim).
- All repository URLs rewritten to github.com/biasclear/biasclear; .github/CODEOWNERS removed (not needed in an archived snapshot).
